<?php
/**
 * Plugin Name: Infinite Vertical Carousel
 * Description: Elementor widget for infinite vertical image carousel with 1/2 columns, reverse scroll, hover pause, links, lightbox, speed, gap, border, radius and advanced styling.
 * Version: 1.0.0
 * Author: Webzlo
 * Text Domain: ivc
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class IVC_Plugin {

	public function __construct() {
		add_action( 'plugins_loaded', [ $this, 'init' ] );
	}

	public function init() {

		if ( ! did_action( 'elementor/loaded' ) ) {
			add_action( 'admin_notices', [ $this, 'elementor_missing_notice' ] );
			return;
		}

		add_action( 'elementor/widgets/register', [ $this, 'register_widget' ] );
	}

	public function elementor_missing_notice() {
		if ( current_user_can( 'activate_plugins' ) ) {
			echo '<div class="notice notice-warning is-dismissible"><p>';
			echo esc_html__( 'Infinite Vertical Carousel requires Elementor to be installed and activated.', 'ivc' );
			echo '</p></div>';
		}
	}

	public function register_widget( $widgets_manager ) {
		require_once __DIR__ . '/widget.php';

		if ( class_exists( '\IVC_Infinite_Vertical_Carousel' ) ) {
			$widgets_manager->register( new \IVC_Infinite_Vertical_Carousel() );
		}
	}
}

new IVC_Plugin();