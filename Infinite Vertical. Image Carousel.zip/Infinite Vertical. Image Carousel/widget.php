<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class IVC_Infinite_Vertical_Carousel extends \Elementor\Widget_Base {

	public function get_name() {
		return 'infinite_vertical_carousel';
	}

	public function get_title() {
		return esc_html__( 'Infinite Vertical Carousel', 'ivc' );
	}

	public function get_icon() {
		return 'eicon-slider-vertical';
	}

	public function get_categories() {
		return [ 'general' ];
	}

	public function get_keywords() {
		return [ 'carousel', 'slider', 'vertical', 'image', 'marquee', 'gallery' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'ivc_content_section',
			[
				'label' => esc_html__( 'Images', 'ivc' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'image',
			[
				'label'   => esc_html__( 'Choose Image', 'ivc' ),
				'type'    => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

		$repeater->add_control(
			'link',
			[
				'label'       => esc_html__( 'Image Link', 'ivc' ),
				'type'        => \Elementor\Controls_Manager::URL,
				'placeholder' => 'https://example.com',
				'dynamic'     => [
					'active' => true,
				],
			]
		);

		$this->add_control(
			'images',
			[
				'label'       => esc_html__( 'Image List', 'ivc' ),
				'type'        => \Elementor\Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'title_field' => esc_html__( 'Carousel Image', 'ivc' ),
			]
		);

		$this->add_control(
			'columns',
			[
				'label'   => esc_html__( 'Columns', 'ivc' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => '2',
				'options' => [
					'1' => esc_html__( '1 Column', 'ivc' ),
					'2' => esc_html__( '2 Columns', 'ivc' ),
				],
			]
		);

		$this->add_control(
			'direction',
			[
				'label'   => esc_html__( 'Scroll Direction', 'ivc' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'alternate',
				'options' => [
					'up'        => esc_html__( 'Up', 'ivc' ),
					'down'      => esc_html__( 'Down', 'ivc' ),
					'alternate' => esc_html__( 'Alternate', 'ivc' ),
				],
			]
		);

		$this->add_control(
			'speed',
			[
				'label' => esc_html__( 'Animation Speed', 'ivc' ),
				'type'  => \Elementor\Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 5,
						'max' => 100,
					],
				],
				'default' => [
					'size' => 25,
				],
			]
		);

		$this->add_control(
			'mobile_speed',
			[
				'label' => esc_html__( 'Mobile Speed', 'ivc' ),
				'type'  => \Elementor\Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 5,
						'max' => 100,
					],
				],
				'default' => [
					'size' => 20,
				],
			]
		);

		$this->add_control(
			'pause_hover',
			[
				'label'        => esc_html__( 'Pause On Hover', 'ivc' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'ivc' ),
				'label_off'    => esc_html__( 'No', 'ivc' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'lightbox',
			[
				'label'        => esc_html__( 'Enable Lightbox', 'ivc' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'ivc' ),
				'label_off'    => esc_html__( 'No', 'ivc' ),
				'return_value' => 'yes',
				'default'      => '',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'ivc_layout_style',
			[
				'label' => esc_html__( 'Layout Style', 'ivc' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'carousel_height',
			[
				'label'      => esc_html__( 'Carousel Height', 'ivc' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'vh' ],
				'range'      => [
					'px' => [
						'min' => 200,
						'max' => 1400,
					],
					'vh' => [
						'min' => 20,
						'max' => 100,
					],
				],
				'default' => [
					'size' => 700,
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .ivc-wrapper' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'column_gap',
			[
				'label' => esc_html__( 'Column Gap', 'ivc' ),
				'type'  => \Elementor\Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 120,
					],
				],
				'default' => [
					'size' => 20,
				],
				'selectors' => [
					'{{WRAPPER}} .ivc-wrapper' => 'gap: {{SIZE}}px;',
				],
			]
		);

		$this->add_responsive_control(
			'image_gap',
			[
				'label' => esc_html__( 'Image Gap / Space', 'ivc' ),
				'type'  => \Elementor\Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 120,
					],
				],
				'default' => [
					'size' => 20,
				],
				'selectors' => [
					'{{WRAPPER}} .ivc-track' => 'gap: {{SIZE}}px;',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'ivc_image_style',
			[
				'label' => esc_html__( 'Image Style', 'ivc' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'image_height',
			[
				'label'      => esc_html__( 'Image Height', 'ivc' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min' => 80,
						'max' => 1000,
					],
				],
				'default' => [
					'size' => 420,
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .ivc-item img' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'object_fit',
			[
				'label'   => esc_html__( 'Object Fit', 'ivc' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'cover',
				'options' => [
					'cover'   => esc_html__( 'Cover', 'ivc' ),
					'contain' => esc_html__( 'Contain', 'ivc' ),
					'fill'    => esc_html__( 'Fill', 'ivc' ),
				],
				'selectors' => [
					'{{WRAPPER}} .ivc-item img' => 'object-fit: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'image_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'ivc' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'default'    => [
					'top'      => 24,
					'right'    => 24,
					'bottom'   => 24,
					'left'     => 24,
					'unit'     => 'px',
					'isLinked' => true,
				],
				'selectors' => [
					'{{WRAPPER}} .ivc-item img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name'     => 'image_border',
				'label'    => esc_html__( 'Border', 'ivc' ),
				'selector' => '{{WRAPPER}} .ivc-item img',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'image_shadow',
				'label'    => esc_html__( 'Box Shadow', 'ivc' ),
				'selector' => '{{WRAPPER}} .ivc-item img',
			]
		);

		$this->add_control(
			'image_opacity',
			[
				'label' => esc_html__( 'Image Opacity', 'ivc' ),
				'type'  => \Elementor\Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min'  => 0.1,
						'max'  => 1,
						'step' => 0.1,
					],
				],
				'default' => [
					'size' => 1,
				],
				'selectors' => [
					'{{WRAPPER}} .ivc-item img' => 'opacity: {{SIZE}};',
				],
			]
		);

		$this->add_responsive_control(
			'image_padding',
			[
				'label'      => esc_html__( 'Image Padding', 'ivc' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .ivc-item img' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'ivc_effects_style',
			[
				'label' => esc_html__( 'Effects', 'ivc' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'hover_zoom',
			[
				'label' => esc_html__( 'Hover Zoom', 'ivc' ),
				'type'  => \Elementor\Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min'  => 1,
						'max'  => 1.3,
						'step' => 0.01,
					],
				],
				'default' => [
					'size' => 1.03,
				],
			]
		);

		$this->add_control(
			'hover_transition',
			[
				'label' => esc_html__( 'Hover Transition Speed', 'ivc' ),
				'type'  => \Elementor\Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min'  => 0.1,
						'max'  => 3,
						'step' => 0.1,
					],
				],
				'default' => [
					'size' => 0.35,
				],
			]
		);

		$this->add_control(
			'fade_edges',
			[
				'label'        => esc_html__( 'Gradient Fade Edges', 'ivc' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'ivc' ),
				'label_off'    => esc_html__( 'No', 'ivc' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'fade_color',
			[
				'label'     => esc_html__( 'Fade Color', 'ivc' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'condition' => [
					'fade_edges' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'fade_size',
			[
				'label' => esc_html__( 'Fade Size', 'ivc' ),
				'type'  => \Elementor\Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 20,
						'max' => 300,
					],
				],
				'default' => [
					'size' => 120,
				],
				'selectors' => [
					'{{WRAPPER}} .ivc-wrapper.ivc-fade::before, {{WRAPPER}} .ivc-wrapper.ivc-fade::after' => 'height: {{SIZE}}px;',
				],
			]
		);

		$this->end_controls_section();
	}

	protected function render() {

		$settings = $this->get_settings_for_display();

		if ( empty( $settings['images'] ) || ! is_array( $settings['images'] ) ) {
			return;
		}

		$uid           = 'ivc-' . esc_attr( $this->get_id() );
		$columns       = isset( $settings['columns'] ) ? sanitize_text_field( $settings['columns'] ) : '2';
		$direction     = isset( $settings['direction'] ) ? sanitize_text_field( $settings['direction'] ) : 'alternate';
		$speed         = ! empty( $settings['speed']['size'] ) ? absint( $settings['speed']['size'] ) : 25;
		$mobile_speed  = ! empty( $settings['mobile_speed']['size'] ) ? absint( $settings['mobile_speed']['size'] ) : 20;
		$pause_hover   = ! empty( $settings['pause_hover'] ) && 'yes' === $settings['pause_hover'] ? 'ivc-pause-hover' : '';
		$fade_edges    = ! empty( $settings['fade_edges'] ) && 'yes' === $settings['fade_edges'] ? 'ivc-fade' : '';
		$fade_color    = ! empty( $settings['fade_color'] ) ? sanitize_hex_color( $settings['fade_color'] ) : '#ffffff';
		$hover_zoom    = ! empty( $settings['hover_zoom']['size'] ) ? floatval( $settings['hover_zoom']['size'] ) : 1.03;
		$transition    = ! empty( $settings['hover_transition']['size'] ) ? floatval( $settings['hover_transition']['size'] ) : 0.35;

		$col_1 = [];
		$col_2 = [];

		foreach ( $settings['images'] as $index => $item ) {
			if ( empty( $item['image']['url'] ) ) {
				continue;
			}

			if ( '2' === $columns ) {
				if ( 0 === $index % 2 ) {
					$col_1[] = $item;
				} else {
					$col_2[] = $item;
				}
			} else {
				$col_1[] = $item;
			}
		}

		if ( empty( $col_1 ) ) {
			return;
		}

		$first_direction  = 'ivc-up';
		$second_direction = 'ivc-down';

		if ( 'down' === $direction ) {
			$first_direction  = 'ivc-down';
			$second_direction = 'ivc-down';
		} elseif ( 'up' === $direction ) {
			$first_direction  = 'ivc-up';
			$second_direction = 'ivc-up';
		} else {
			$first_direction  = 'ivc-up';
			$second_direction = 'ivc-down';
		}
		?>

		<style>
			#<?php echo esc_attr( $uid ); ?> {
				--ivc-speed: <?php echo esc_attr( $speed ); ?>s;
				--ivc-mobile-speed: <?php echo esc_attr( $mobile_speed ); ?>s;
				--ivc-fade-color: <?php echo esc_attr( $fade_color ); ?>;
				--ivc-hover-zoom: <?php echo esc_attr( $hover_zoom ); ?>;
				--ivc-transition: <?php echo esc_attr( $transition ); ?>s;
			}

			#<?php echo esc_attr( $uid ); ?>.ivc-wrapper {
				display: flex;
				overflow: hidden;
				position: relative;
				width: 100%;
			}

			#<?php echo esc_attr( $uid ); ?> .ivc-column {
				flex: 1;
				overflow: hidden;
				position: relative;
				min-width: 0;
			}

			#<?php echo esc_attr( $uid ); ?> .ivc-track {
				display: flex;
				flex-direction: column;
				animation-duration: var(--ivc-speed);
				animation-timing-function: linear;
				animation-iteration-count: infinite;
				will-change: transform;
			}

			#<?php echo esc_attr( $uid ); ?> .ivc-up {
				animation-name: ivcScrollUp;
			}

			#<?php echo esc_attr( $uid ); ?> .ivc-down {
				animation-name: ivcScrollDown;
			}

			#<?php echo esc_attr( $uid ); ?>.ivc-pause-hover:hover .ivc-track {
				animation-play-state: paused;
			}

			#<?php echo esc_attr( $uid ); ?> .ivc-item {
				display: block;
				line-height: 0;
				overflow: hidden;
			}

			#<?php echo esc_attr( $uid ); ?> .ivc-item img {
				width: 100%;
				display: block;
				object-position: center;
				transition: transform var(--ivc-transition) ease;
			}

			#<?php echo esc_attr( $uid ); ?> .ivc-item:hover img {
				transform: scale(var(--ivc-hover-zoom));
			}

			#<?php echo esc_attr( $uid ); ?>.ivc-fade::before,
			#<?php echo esc_attr( $uid ); ?>.ivc-fade::after {
				content: "";
				position: absolute;
				left: 0;
				width: 100%;
				z-index: 9;
				pointer-events: none;
			}

			#<?php echo esc_attr( $uid ); ?>.ivc-fade::before {
				top: 0;
				background: linear-gradient(to bottom, var(--ivc-fade-color), rgba(255,255,255,0));
			}

			#<?php echo esc_attr( $uid ); ?>.ivc-fade::after {
				bottom: 0;
				background: linear-gradient(to top, var(--ivc-fade-color), rgba(255,255,255,0));
			}

			@keyframes ivcScrollUp {
				0% { transform: translateY(0); }
				100% { transform: translateY(-50%); }
			}

			@keyframes ivcScrollDown {
				0% { transform: translateY(-50%); }
				100% { transform: translateY(0); }
			}

			@media (max-width: 767px) {
				#<?php echo esc_attr( $uid ); ?> .ivc-track {
					animation-duration: var(--ivc-mobile-speed);
				}
			}
		</style>

		<div id="<?php echo esc_attr( $uid ); ?>" class="ivc-wrapper <?php echo esc_attr( trim( $pause_hover . ' ' . $fade_edges ) ); ?>">
			<?php
			$this->render_column( $col_1, $first_direction, $settings );

			if ( '2' === $columns && ! empty( $col_2 ) ) {
				$this->render_column( $col_2, $second_direction, $settings );
			}
			?>
		</div>

		<?php
	}

	private function render_column( $items, $animation_class, $settings ) {
		if ( empty( $items ) || ! is_array( $items ) ) {
			return;
		}
		?>

		<div class="ivc-column">
			<div class="ivc-track <?php echo esc_attr( $animation_class ); ?>">

				<?php for ( $i = 0; $i < 2; $i++ ) : ?>
					<?php foreach ( $items as $item ) : ?>

						<?php
						if ( empty( $item['image']['url'] ) ) {
							continue;
						}

						$image_url = esc_url( $item['image']['url'] );
						$image_id  = ! empty( $item['image']['id'] ) ? absint( $item['image']['id'] ) : 0;
						$alt       = $image_id ? get_post_meta( $image_id, '_wp_attachment_image_alt', true ) : '';
						$alt       = $alt ? esc_attr( $alt ) : esc_attr__( 'Carousel Image', 'ivc' );

						$link_url = ! empty( $item['link']['url'] ) ? esc_url( $item['link']['url'] ) : '';
						$target   = ! empty( $item['link']['is_external'] ) ? ' target="_blank"' : '';
						$rel      = [];

						if ( ! empty( $item['link']['nofollow'] ) ) {
							$rel[] = 'nofollow';
						}

						if ( ! empty( $item['link']['is_external'] ) ) {
							$rel[] = 'noopener';
						}

						$rel_attr = ! empty( $rel ) ? ' rel="' . esc_attr( implode( ' ', $rel ) ) . '"' : '';
						?>

						<?php if ( ! empty( $settings['lightbox'] ) && 'yes' === $settings['lightbox'] ) : ?>

							<a class="ivc-item" href="<?php echo esc_url( $image_url ); ?>" data-elementor-open-lightbox="yes">
								<img src="<?php echo esc_url( $image_url ); ?>" alt="<?php echo esc_attr( $alt ); ?>" loading="lazy">
							</a>

						<?php elseif ( $link_url ) : ?>

							<a class="ivc-item" href="<?php echo esc_url( $link_url ); ?>"<?php echo $target . $rel_attr; ?>>
								<img src="<?php echo esc_url( $image_url ); ?>" alt="<?php echo esc_attr( $alt ); ?>" loading="lazy">
							</a>

						<?php else : ?>

							<div class="ivc-item">
								<img src="<?php echo esc_url( $image_url ); ?>" alt="<?php echo esc_attr( $alt ); ?>" loading="lazy">
							</div>

						<?php endif; ?>

					<?php endforeach; ?>
				<?php endfor; ?>

			</div>
		</div>

		<?php
	}
}